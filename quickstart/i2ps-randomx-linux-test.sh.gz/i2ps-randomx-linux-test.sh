#!/usr/bin/env bash
# I2PS Engineering: interactive online RandomX CPU *engineering test*.
# This is NOT the unfinished v0.4 24-hour benchmark product.
set -Eeuo pipefail
VERSION=6.26.0
ASSET="xmrig-${VERSION}-linux-static-x64.tar.gz"
EXPECTED_SHA=fc6f8ae5f64e4f17481f7e3be29a1c56949f216a998414188003eae1db20c9e5
URL="https://github.com/xmrig/xmrig/releases/download/v${VERSION}/${ASSET}"
MINUTES=10; THREADS=''; PLAN=0; XMRIG=''
fail() { printf 'ERROR: %s\n' "$*" >&2; exit 1; }
usage() { printf 'Usage: bash i2ps-randomx-linux-test.sh [--plan] [--minutes 10] [--threads N] [--xmrig /path/to/xmrig]\n'; }
while (($#)); do
  case "$1" in
    --plan) PLAN=1; shift;;
    --minutes) (($#>=2)) || fail 'Missing --minutes value'; MINUTES="$2"; shift 2;;
    --threads) (($#>=2)) || fail 'Missing --threads value'; THREADS="$2"; shift 2;;
    --xmrig) (($#>=2)) || fail 'Missing --xmrig value'; XMRIG="$2"; shift 2;;
    --help|-h) usage; exit 0;;
    *) fail "Unknown argument $1";;
  esac
done
[[ "$MINUTES" =~ ^[0-9]+$ ]] && ((MINUTES>=1 && MINUTES<=1440)) || fail 'Minutes must be between 1 and 1440'
if [[ -n "$THREADS" ]]; then
  [[ "$THREADS" =~ ^[0-9]+$ ]] && ((THREADS>=1 && THREADS<=256)) || fail 'Threads must be 1-256'
fi
[[ "$(uname -s)" == Linux && "$(uname -m)" == x86_64 ]] || fail 'This direct test currently supports Linux x86-64 only'
[[ "$(id -u)" != 0 ]] || fail 'Run as your normal Linux user; do not use sudo on this script'
for bin in python3 timeout; do command -v "$bin" >/dev/null || fail "Missing $bin; run sudo apt-get install -y python3 coreutils"; done
if [[ -z "$XMRIG" ]]; then
  for bin in curl sha256sum tar; do command -v "$bin" >/dev/null || fail "Missing $bin; run sudo apt-get install -y curl ca-certificates coreutils tar"; done
fi
printf 'I2PS Engineering | ONLINE RandomX CPU engineering test | %s minutes\n' "$MINUTES"
if ((PLAN)); then
  printf 'Plan: use verified official XMRig %s, require your pool and public Monero address, request explicit RUN consent, collect real XMRig results.\n' "$VERSION"
  printf 'No downloads, installs or mining have occurred.\n'
  exit 0
fi
if [[ -t 0 ]]; then
  read -r -p 'Pool server (host:port, no https://): ' POOL
  read -r -p 'PUBLIC Monero receiving address (NEVER seed or private key): ' WALLET
  read -r -p 'Does this pool port use TLS? [Y/n]: ' TLS_ANSWER
else
  fail 'Run interactively in a terminal so you can enter your pool and wallet and authorize mining'
fi
[[ "$POOL" =~ ^[A-Za-z0-9.-]+:[0-9]{1,5}$ ]] || fail 'Invalid pool format. Expected pool.example.com:443'
PORT="${POOL##*:}"; ((10#$PORT>=1 && 10#$PORT<=65535)) || fail 'Invalid pool port'
[[ "$WALLET" =~ ^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]+$ ]] && [[ "$WALLET" == 4* || "$WALLET" == 8* ]] && ((${#WALLET}==95 || ${#WALLET}==106)) || fail 'Invalid-looking public Monero address'
TLS=true; [[ "${TLS_ANSWER,,}" == n || "${TLS_ANSWER,,}" == no ]] && TLS=false
printf '\nThis runs REAL CPU mining for up to %s minutes, consuming power and generating heat.\n' "$MINUTES"
printf 'Pool shares will be credited to the PUBLIC address YOU supplied; XMRig has its own developer donation mechanism.\n'
printf 'It is NOT the public I2PS v0.4 24-hour Dev Wallet benchmark. Ctrl+C stops the test.\n'
read -r -p 'Type RUN to authorize CPU mining now: ' CONFIRM
[[ "$CONFIRM" == RUN ]] || fail 'Not authorized; no mining started'
BASE="${HOME}/.local/share/i2ps-randomx-quick"; RESULTS="${HOME}/i2ps-randomx-results"
mkdir -p -m 700 "$BASE" "$RESULTS"; chmod 700 "$BASE" "$RESULTS"
if [[ -n "$XMRIG" ]]; then
  [[ -x "$XMRIG" ]] || fail 'Provided XMRig is not executable'
  BIN="$XMRIG"
else
  BIN="$BASE/xmrig-${VERSION}"
  if [[ ! -x "$BIN" ]]; then
    ARCHIVE="$BASE/$ASSET"
    printf 'Downloading official XMRig %s from GitHub...\n' "$VERSION"
    curl --fail --location --silent --show-error --retry 2 --max-time 120 -o "$ARCHIVE" "$URL" || fail 'Upstream download failed'
    printf '%s  %s\n' "$EXPECTED_SHA" "$ARCHIVE" | sha256sum --check --status || fail 'Official SHA256 mismatch; refusing to execute'
    ENTRY=$(tar -tzf "$ARCHIVE" | grep -E '(^|/)xmrig$' || true)
    [[ "$(printf '%s\n' "$ENTRY" | grep -c .)" == 1 ]] || fail 'Unexpected archive structure'
    tar -xOzf "$ARCHIVE" "$ENTRY" > "$BIN.tmp"
    chmod 700 "$BIN.tmp" && mv -f "$BIN.tmp" "$BIN"
    printf '%s\n' "$EXPECTED_SHA" > "$BASE/source-archive.sha256"
    sha256sum "$BIN" | awk '{print $1}' > "$BASE/executable.sha256"
  else
    # The binary must have been installed from the verified archive earlier.
    [[ -f "$BASE/source-archive.sha256" ]] && [[ "$(cat "$BASE/source-archive.sha256")" == "$EXPECTED_SHA" ]] || fail 'Cached executable not traceable to verified release; remove cache and retry'
    [[ -f "$BASE/executable.sha256" ]] && [[ "$(sha256sum "$BIN" | awk '{print $1}')" == "$(cat "$BASE/executable.sha256")" ]] || fail 'Cached executable failed integrity verification; remove cache and retry'
  fi
fi
RUNID=$(date -u '+%Y%m%d_%H%M%S')
LOG="$RESULTS/$RUNID.log"; REPORT="$RESULTS/$RUNID.json"
umask 077
CONFIG=$(mktemp "${TMPDIR:-/tmp}/i2ps-rx.XXXXXXXX.json")
cleanup() { rm -f "$CONFIG"; }
trap cleanup EXIT
python3 - "$CONFIG" "$POOL" "$WALLET" "$TLS" <<'PY'
import json, os, sys
path, pool, wallet, tls = sys.argv[1:]
cfg = {'autosave': False, 'coin': 'monero', 'algo': 'rx/0',
       'pools': [{'url': pool, 'user': wallet, 'pass': 'x', 'tls': tls == 'true', 'keepalive': True}],
       'cpu': {'enabled': True, 'huge-pages': True},
       'opencl': {'enabled': False}, 'cuda': {'enabled': False}, 'http': {'enabled': False},
       'print-time': 10, 'colors': False}
with open(path, 'w') as f: json.dump(cfg, f)
os.chmod(path, 0o600)
PY
ARG=(--config "$CONFIG" --no-color --print-time 10 --log-file "$LOG")
[[ -n "$THREADS" ]] && ARG+=(--threads "$THREADS")
SECONDS_TO_RUN=$((MINUTES*60))
printf '\nStarting real RandomX: wait for speed 10s/60s/15m measurements...\n'
set +e
timeout --foreground --signal=TERM --kill-after=7s "$SECONDS_TO_RUN" "$BIN" "${ARG[@]}"
EXITCODE=$?
set -e
# Exclude the public address from the stored raw diagnostic log.
if [[ -f "$LOG" ]]; then
  python3 - "$LOG" "$WALLET" <<'PY'
import sys
from pathlib import Path
p=Path(sys.argv[1]); p.write_text(p.read_text(errors='replace').replace(sys.argv[2],'[PUBLIC_WALLET]'))
PY
  chmod 600 "$LOG"
fi
python3 - "$LOG" "$REPORT" "$SECONDS_TO_RUN" "$EXITCODE" "$POOL" "$THREADS" <<'PY'
import datetime as dt, json, re, statistics, sys
from pathlib import Path
log, outfile, planned, exitcode, pool, threads = sys.argv[1:]
txt = Path(log).read_text(errors='replace') if Path(log).exists() else ''
speeds=[]
for line in txt.splitlines():
    match=re.search(r'\bspeed\s+10s/60s/15m\s+(\d+(?:\.\d+)?)',line,re.I)
    if match:
        unit=re.search(r'\b([kKmM]?)[hH]/s\b',line)
        n=float(match.group(1))*{'':1,'k':1000,'m':1000000}.get((unit.group(1) if unit else '').lower(),1)
        if n>0: speeds.append(n)
a=[int(x) for x in re.findall(r'\baccepted\s*\((\d+)\s*/\s*\d+\)', txt,re.I)]
r=[int(x) for x in re.findall(r'\brejected\s*\((\d+)\s*/\s*\d+\)',txt,re.I)]
accepted=max(a,default=0); rejected=max(r,default=0)
completed = exitcode=='124'  # GNU timeout reached the requested duration
status=('POOL_VERIFIED' if completed and accepted and speeds else
        'HASHRATE_ONLY_NO_POOL_ACCEPTANCE' if completed and speeds else
        'STOPPED_OR_INCOMPLETE')
info={'kind':'ENGINEERING_SMOKE_TEST_NOT_24H_V04','date_utc':dt.datetime.now(dt.timezone.utc).isoformat(),
      'pool':pool, 'duration_requested_seconds':int(planned), 'timeout_exit_code':int(exitcode),
      'threads_requested':int(threads) if threads else 'auto', 'hashrate_samples':len(speeds),
      'median_hs':round(statistics.median(speeds),2) if speeds else None,
      'mean_hs':round(statistics.fmean(speeds),2) if speeds else None,
      'min_hs':min(speeds,default=None),'max_hs':max(speeds,default=None),
      'accepted_shares':accepted,'rejected_events_observed':rejected,'status':status}
Path(outfile).write_text(json.dumps(info,indent=2)+'\n')
print('\n=== I2PS RANDOMX ONLINE CPU RESULT ===')
for key in ('status','threads_requested','median_hs','mean_hs','min_hs','max_hs','hashrate_samples','accepted_shares','rejected_events_observed'):
    print(f'{key:29s}: {info[key]}')
print('JSON report:',outfile)
print('Diagnostic log:',log)
print('This short test is NOT a validated 24-hour v0.4 benchmark.')
if not speeds: sys.exit(3)
if not completed or not accepted: sys.exit(2)
PY
