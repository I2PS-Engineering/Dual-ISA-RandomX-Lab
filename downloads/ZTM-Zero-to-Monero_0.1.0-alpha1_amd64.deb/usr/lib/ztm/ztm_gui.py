#!/usr/bin/env python3
"""ZTM — Zero to Monero; real GUI for Ubuntu and opt-in RandomX test.
No automatic mining, persistence, daemon, or privilege escalation for XMRig.
"""
from __future__ import annotations

import json
import os
import platform
import queue
import re
import shutil
import signal
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import messagebox, ttk

DARK = '#070e18'
PANEL = '#0c1b2d'
CYAN = '#39bfff'
WHITE = '#f2f8ff'
MUTED = '#a0b8ce'
APP = Path(__file__).resolve().parent
ENGINE = APP / 'ztm_engine.py'
RESULTS = Path.home() / 'ZTM-Results'


def os_is_supported(system=None, architecture=None) -> bool:
    return (system or platform.system()) == 'Linux' and (architecture or platform.machine()).lower() in ('x86_64', 'amd64')


def prepare_steps(pkexec='pkexec'):
    """Only apt operations with a GUI privileged authentication; no background changes."""
    return [
        ('APT refresh', [pkexec, '/usr/bin/apt-get', 'update']),
        ('Install prerequisites', [pkexec, '/usr/bin/apt-get', 'install', '-y', 'ca-certificates', 'curl', 'tar', 'python3']),
        ('Install official, SHA-256-verified XMRig', [sys.executable, str(ENGINE), '--prepare']),
    ]


def benchmark_session(pool, wallet, tls, minutes, threads):
    from ztm_engine import validate_pool, validate_address, BenchError
    pool = validate_pool(pool)
    wallet = validate_address(wallet)
    if minutes not in (1, 10, 30, 60, 1440):
        raise BenchError('Choose one of the supported durations.')
    if threads and not (1 <= threads <= (os.cpu_count() or 1)):
        raise BenchError('Thread count exceeds detected CPU count.')
    return {'pool': pool, 'wallet': wallet, 'tls': tls, 'minutes': minutes, 'threads': threads}


class ZTMApp:
    def __init__(self, root):
        self.root = root
        self.root.title('ZTM — Zero to Monero | I2PS Engineering')
        self.root.geometry('1090x760')
        self.root.minsize(850, 650)
        self.root.configure(bg=DARK)
        self.q = queue.Queue()
        self.process = None
        self.busy = False
        self.prepared = False
        self.cancelled = False
        self.current_wallet = None
        self.state = tk.StringVar(value='1 · Prepare Linux & XMRig')
        self.status = tk.StringVar(value='Ready to prepare this Linux machine.')
        self.rate = tk.StringVar(value='— H/s')
        self.shares = tk.StringVar(value='Accepted — / Rejected —')
        self.duration = tk.StringVar(value='10 minutes — quick diagnostic')
        self.threads = tk.StringVar(value='Auto')
        self.pool = tk.StringVar()
        self.wallet = tk.StringVar()
        self.tls = tk.BooleanVar(value=True)
        self.upgrade_all = tk.BooleanVar(value=False)
        self.confirm_power = tk.BooleanVar(value=False)
        self.confirm_reward = tk.BooleanVar(value=False)
        self.view()
        self.root.after(100, self.pump)
        self.root.protocol('WM_DELETE_WINDOW', self.close)
        if not os_is_supported():
            self.append('UNSUPPORTED: this engineering build targets Linux x86-64 only.')
            self.prepare_btn.configure(state='disabled')

    def label(self, parent, text, size=11, color=WHITE, bold=False, **kw):
        return tk.Label(parent, text=text, fg=color, bg=parent['bg'], font=('DejaVu Sans', size, 'bold' if bold else 'normal'), **kw)

    def view(self):
        style = ttk.Style(self.root)
        style.theme_use('clam')
        style.configure('ZTM.TButton', font=('DejaVu Sans', 10, 'bold'), padding=(13, 10))
        style.configure('ZTM.TEntry', fieldbackground='#142740', foreground=WHITE, insertcolor=WHITE)
        bar = tk.Frame(self.root, bg=PANEL, pady=13, padx=20)
        bar.pack(fill='x')
        logo = APP / 'i2ps-logo.png'
        if logo.is_file():
            self.logo_image = tk.PhotoImage(file=str(logo))
            tk.Label(bar, image=self.logo_image, bg=PANEL).pack(side='left', padx=(0,15))
        self.label(bar, 'ZTM', 23, CYAN, True).pack(side='left')
        self.label(bar, '  ZERO TO MONERO  |  I2PS ENGINEERING', 13, WHITE, True).pack(side='left')
        self.label(bar, '  Linux x86-64 · Engineering Preview', 10, MUTED).pack(side='right')
        main = tk.Frame(self.root, bg=DARK, padx=20, pady=13)
        main.pack(fill='both', expand=True)
        self.label(main, 'ONE INSTALLATION. LIVE TERMINAL. ACTUAL RANDOMX MEASUREMENTS.', 12, CYAN, True).pack(anchor='w', pady=(0, 6))
        self.label(main, 'Preparation runs APT update, installs prerequisites, then downloads verified official XMRig.\nNo mining begins until you enter your details and authorize it.', 10, MUTED, justify='left').pack(anchor='w')
        tk.Checkbutton(main, text='Also upgrade already-installed Ubuntu packages (apt-get upgrade -y; optional)', variable=self.upgrade_all, bg=DARK, fg=WHITE, activebackground=DARK, activeforeground=WHITE, selectcolor=DARK).pack(anchor='w', pady=(5,0))
        row = tk.Frame(main, bg=DARK)
        row.pack(fill='x', pady=(12, 8))
        self.prepare_btn = ttk.Button(row, text='1   PREPARE LINUX + INSTALL XMRIG', style='ZTM.TButton', command=self.prepare)
        self.prepare_btn.pack(side='left')
        self.stop_btn = ttk.Button(row, text='STOP', style='ZTM.TButton', command=self.stop, state='disabled')
        self.stop_btn.pack(side='left', padx=10)
        self.label(row, '', 10).pack(side='left')
        self.label(row, '', 10).pack(side='left')
        self.label(row, 'CURRENT STEP: ', 9, MUTED).pack(side='left')
        self.label(row, '', 9).pack(side='left')
        tk.Label(row, textvariable=self.state, fg=CYAN, bg=DARK, font=('DejaVu Sans', 10, 'bold')).pack(side='left')
        panels = tk.PanedWindow(main, orient=tk.VERTICAL, sashwidth=5, bg=DARK, bd=0)
        panels.pack(fill='both', expand=True)
        term_frame = tk.Frame(panels, bg=PANEL, padx=10, pady=8)
        self.label(term_frame, 'LIVE TERMINAL OUTPUT  •  APT / SETUP / XMRIG', 10, CYAN, True).pack(anchor='w')
        terminal = tk.Frame(term_frame, bg=PANEL)
        terminal.pack(fill='both', expand=True)
        self.terminal = tk.Text(terminal, wrap='word', font=('DejaVu Sans Mono', 9), bg='#050b12', fg='#baf9de', insertbackground=WHITE, bd=0, state='disabled', relief='flat')
        sc = ttk.Scrollbar(terminal, orient='vertical', command=self.terminal.yview)
        self.terminal.configure(yscrollcommand=sc.set)
        self.terminal.pack(side='left', fill='both', expand=True)
        sc.pack(side='right', fill='y')
        panels.add(term_frame, minsize=130, stretch='always')
        setup = tk.Frame(panels, bg=PANEL, padx=10, pady=8)
        self.label(setup, '2   BENCHMARK SETUP', 11, CYAN, True).pack(anchor='w')
        fields = tk.Frame(setup, bg=PANEL)
        fields.pack(fill='x', pady=7)
        for col in range(4):
            fields.grid_columnconfigure(col, weight=1 if col in (1, 3) else 0)
        self.label(fields, 'POOL HOST:PORT', 9, MUTED).grid(row=0, column=0, sticky='w', padx=(0,7), pady=5)
        self.pool_entry = ttk.Entry(fields, textvariable=self.pool, width=24)
        self.pool_entry.grid(row=0,column=1,sticky='ew',padx=(0,22))
        self.label(fields, 'PUBLIC WALLET', 9, MUTED).grid(row=0,column=2,sticky='w',padx=(0,7))
        self.wallet_entry = ttk.Entry(fields, textvariable=self.wallet, width=42)
        self.wallet_entry.grid(row=0,column=3,sticky='ew')
        self.label(fields, 'DURATION', 9, MUTED).grid(row=1,column=0,sticky='w',pady=5)
        self.duration_menu = ttk.Combobox(fields, textvariable=self.duration, state='readonly', values=[
            '1 minute — connectivity check', '10 minutes — quick diagnostic',
            '30 minutes — quick diagnostic', '60 minutes — longer diagnostic',
            '1440 minutes — 24-hour observation'])
        self.duration_menu.grid(row=1,column=1,sticky='ew',padx=(0,22))
        self.label(fields, 'CPU THREADS', 9, MUTED).grid(row=1,column=2,sticky='w')
        self.thread_entry = ttk.Entry(fields, textvariable=self.threads)
        self.thread_entry.grid(row=1,column=3,sticky='ew')
        tk.Checkbutton(setup, text='TLS connection to the pool (use only if the selected pool port supports TLS)', variable=self.tls, bg=PANEL, fg=WHITE, activebackground=PANEL, activeforeground=WHITE, selectcolor=DARK).pack(anchor='w')
        tk.Checkbutton(setup, text='I authorize real CPU work for the selected duration, including electricity use and heat.', variable=self.confirm_power, bg=PANEL, fg=WHITE, activebackground=PANEL, activeforeground=WHITE, selectcolor=DARK).pack(anchor='w')
        tk.Checkbutton(setup, text='I understand this quick engineering test credits pool rewards to the public receiving address I enter; XMRig may also have an upstream developer contribution.', variable=self.confirm_reward, bg=PANEL, fg=WHITE, activebackground=PANEL, activeforeground=WHITE, selectcolor=DARK, wraplength=990, justify='left').pack(anchor='w')
        self.label(setup, 'Only PUBLIC address; never enter seeds, spend keys or view keys. Not the approved v0.4 Dev Wallet 24-hour release.', 9, MUTED).pack(anchor='w', pady=(3, 0))
        buttons = tk.Frame(setup, bg=PANEL)
        buttons.pack(fill='x', pady=(8,0))
        self.benchmark_btn = ttk.Button(buttons, text='START REAL RANDOMX BENCHMARK', style='ZTM.TButton', command=self.benchmark, state='disabled')
        self.benchmark_btn.pack(side='left')
        ttk.Button(buttons, text='OPEN RESULTS FOLDER', style='ZTM.TButton', command=self.open_results).pack(side='left', padx=10)
        tk.Label(buttons, textvariable=self.rate, bg=PANEL, fg=CYAN, font=('DejaVu Sans', 13, 'bold')).pack(side='right')
        tk.Label(setup, textvariable=self.shares, bg=PANEL, fg=MUTED, font=('DejaVu Sans', 9)).pack(anchor='e')
        panels.add(setup, minsize=265, stretch='never')
        footer = tk.Frame(self.root, bg=PANEL, padx=16, pady=8)
        footer.pack(fill='x')
        tk.Label(footer, textvariable=self.status, bg=PANEL, fg=CYAN, anchor='w', font=('DejaVu Sans', 10)).pack(fill='x')
        self.append('ZTM is ready. Click PREPARE LINUX + INSTALL XMRIG to begin. No mining has started.')

    def append(self, line):
        line = re.sub(r'\x1b\[[0-9;]*[A-Za-z]', '', line).replace('\r', '\n')
        if self.current_wallet:
            line = line.replace(self.current_wallet, '[PUBLIC_WALLET]')
        self.terminal.configure(state='normal')
        self.terminal.insert('end', line.rstrip() + '\n')
        # Bounded display for long 24h sessions
        count = int(self.terminal.index('end-1c').split('.')[0])
        if count > 5000:
            self.terminal.delete('1.0', '1000.0')
        self.terminal.see('end')
        self.terminal.configure(state='disabled')
        speed = re.search(r'Measured XMRig speed:\s*([0-9,.]+ H/s)', line)
        if speed:
            self.rate.set(speed.group(1))
        shares = re.search(r'Pool shares.*accepted:\s*(\d+)\s*\|\s*rejected:\s*(\d+)', line)
        if shares:
            self.shares.set(f'Accepted {shares.group(1)} / Rejected {shares.group(2)}')

    def busy_start(self, step):
        self.busy = True
        self.cancelled = False
        self.state.set(step)
        self.prepare_btn.configure(state='disabled')
        self.benchmark_btn.configure(state='disabled')
        self.stop_btn.configure(state='normal')

    def busy_end(self):
        self.busy = False
        self.process = None
        self.current_wallet = None
        self.stop_btn.configure(state='disabled')
        self.prepare_btn.configure(state='normal')
        self.benchmark_btn.configure(state='normal' if self.prepared else 'disabled')

    def run_command(self, command, stdin_payload=None):
        if self.cancelled:
            return 130
        self.q.put(('line', '$ ' + ' '.join('***' if x.startswith('4') and len(x)>80 else x for x in command)))
        try:
            p = subprocess.Popen(command, stdin=subprocess.PIPE if stdin_payload else subprocess.DEVNULL,
                                 stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
                                 errors='replace', bufsize=1, start_new_session=True)
            self.process = p
            if stdin_payload:
                p.stdin.write(stdin_payload + '\n')
                p.stdin.flush()
                p.stdin.close()
            for line in p.stdout:
                if self.cancelled:
                    break
                self.q.put(('line', line))
            if self.cancelled and p.poll() is None:
                self.terminate_process(p)
            return p.wait()
        except Exception as e:
            self.q.put(('line', 'ERROR: ' + str(e)))
            return 1
        finally:
            self.process = None

    def prepare(self):
        if self.busy or not os_is_supported(): return
        if os.geteuid() == 0:
            messagebox.showerror('ZTM', 'Launch ZTM as your regular desktop user, not root.')
            return
        if not shutil.which('pkexec'):
            messagebox.showerror('ZTM', 'pkexec is not installed. Install polkit/pkexec using Ubuntu software tools, then relaunch.')
            return
        if not messagebox.askyesno('ZTM system preparation', 'ZTM will run apt-get update, install required packages, and download official XMRig 6.26.0 (SHA-256 verified).'+ ('\nSystem packages will also be upgraded.' if self.upgrade_all.get() else '') + '\n\nUbuntu will request administrator authorization. Continue?'):
            return
        self.busy_start('1 · Preparing APT and XMRig')
        def work():
            steps = prepare_steps()
            if self.upgrade_all.get():
                steps.insert(1, ('Upgrade installed packages', ['pkexec', '/usr/bin/apt-get', 'upgrade', '-y']))
            for caption, cmd in steps:
                self.q.put(('status', caption))
                result = self.run_command(cmd)
                if result != 0 or self.cancelled:
                    self.q.put(('done-prepare', (False, caption, result)))
                    return
            self.q.put(('done-prepare', (True, 'Preparation complete', 0)))
        threading.Thread(target=work, daemon=True).start()

    def benchmark(self):
        if self.busy or not self.prepared: return
        try:
            minutes = int(self.duration.get().split(' ', 1)[0])
            raw = self.threads.get().strip()
            threads = None if not raw or raw.lower() == 'auto' else int(raw)
            session = benchmark_session(self.pool.get(), self.wallet.get(), self.tls.get(), minutes, threads)
        except Exception as e:
            messagebox.showerror('Benchmark configuration', str(e))
            return
        if not (self.confirm_power.get() and self.confirm_reward.get()):
            messagebox.showerror('Authorization required', 'Read and check both benchmark acknowledgments before starting.')
            return
        text = (f'ZTM will start REAL RandomX CPU mining.\n\nPool: {session["pool"]}\nTLS: {session["tls"]}\nDuration: {minutes} minute(s)\nThreads: {threads or "auto"}\n\nRewards from ordinary pool shares go to the PUBLIC address you entered.\n\nMining consumes electricity and creates heat. You can STOP it at any time.\n\nStart now?')
        if not messagebox.askyesno('Authorize REAL CPU benchmark', text):
            return
        RESULTS.mkdir(parents=True, exist_ok=True)
        self.current_wallet = session['wallet']
        self.busy_start('2 · Online CPU benchmark running')
        self.status.set('Real XMRig online benchmark is running. Press STOP to interrupt.')
        def work():
            cmd = [sys.executable, '-u', str(ENGINE), '--session-stdin', '--output', str(RESULTS)]
            result = self.run_command(cmd, json.dumps(session))
            self.q.put(('done-bench', result))
        threading.Thread(target=work, daemon=True).start()

    def terminate_process(self, proc):
        try:
            if proc.poll() is None:
                os.killpg(proc.pid, signal.SIGINT)
        except ProcessLookupError:
            pass
        except OSError:
            try: proc.terminate()
            except OSError: pass

    def stop(self):
        if not self.busy: return
        if not messagebox.askyesno('Stop ZTM task', 'Stop the current operation? An interrupted benchmark is not complete.'):
            return
        self.cancelled = True
        if self.process:
            self.terminate_process(self.process)
        self.status.set('Stopping the active operation…')

    def pump(self):
        try:
            for _ in range(300):
                typ, payload = self.q.get_nowait()
                if typ == 'line': self.append(payload)
                elif typ == 'status': self.status.set(payload)
                elif typ == 'done-prepare':
                    ok, caption, status = payload
                    self.prepared = ok
                    self.busy_end()
                    self.state.set('2 · Ready for online benchmark' if ok else 'Preparation incomplete')
                    self.status.set('Ready. Enter pool/wallet and authorize benchmark.' if ok else f'Setup failed/stopped: {caption} (exit {status}). Review terminal output.')
                elif typ == 'done-bench':
                    self.busy_end()
                    self.state.set('2 · Finished' if payload == 0 else '2 · Partial / stopped')
                    self.status.set('Measured report written to ~/ZTM-Results.' if payload == 0 else f'Benchmark incomplete (exit {payload}). View log/report in ~/ZTM-Results.')
        except queue.Empty:
            pass
        self.root.after(100, self.pump)

    def open_results(self):
        RESULTS.mkdir(parents=True, exist_ok=True)
        if shutil.which('xdg-open'):
            subprocess.Popen(['xdg-open', str(RESULTS)], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        else:
            messagebox.showinfo('Results folder', str(RESULTS))

    def close(self):
        if self.busy:
            if not messagebox.askyesno('Exit ZTM', 'An operation is in progress. Stop it and close?'):
                return
            self.cancelled = True
            if self.process:
                self.terminate_process(self.process)
            # delay destruction, allowing controller to stop XMRig in its own session
            self.root.after(1200, self.root.destroy)
            return
        self.root.destroy()


def main():
    root = tk.Tk()
    ZTMApp(root)
    root.mainloop()


if __name__ == '__main__':
    main()
