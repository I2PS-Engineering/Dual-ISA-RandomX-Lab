#!/usr/bin/env python3
"""ZTM — Zero to Monero: opt-in ONLINE CPU benchmark for fresh Ubuntu.

This is an engineering diagnostic, not the public v0.4 24-hour Dev Wallet
benchmark or production release. Runs verified official XMRig v6.26.0.
Requires user-chosen pool and public Monero address and explicit consent.
Python standard library only; no sudo required to run this file.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import json
import os
import platform
import re
import signal
import statistics
import subprocess
import sys
import tarfile
import tempfile
import threading
import time
import urllib.request
from urllib.parse import urlparse
from pathlib import Path

VERSION = "6.26.0"
ASSET = "xmrig-6.26.0-linux-static-x64.tar.gz"
ASSET_SHA256 = "fc6f8ae5f64e4f17481f7e3be29a1c56949f216a998414188003eae1db20c9e5"
URL = f"https://github.com/xmrig/xmrig/releases/download/v{VERSION}/{ASSET}"
BASE58 = re.compile(r"^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]+$")
POOL = re.compile(r"^[A-Za-z0-9.-]+:[0-9]{1,5}$")
SPEED = re.compile(r"\bspeed\s+10s/60s/15m\s+([0-9]+(?:\.[0-9]+)?|n/a)(?:\s+([kKmM]?)[hH]/s)?", re.I)
SHARE = re.compile(r"\baccepted\s*\((\d+)\s*/\s*(\d+)\)", re.I)
REJECTED = re.compile(r"\brejected\s*\((\d+)\s*/\s*(\d+)\)", re.I)
MACHINE = ("x86_64", "amd64")
MAX_ARCHIVE = 35 * 1024 * 1024
MAX_BINARY = 30 * 1024 * 1024


class BenchError(Exception):
    pass


def validate_pool(value):
    value = value.strip()
    if not POOL.fullmatch(value):
        raise BenchError("Pool must look like pool.example.org:443 (no https:// prefix).")
    host, port = value.rsplit(":", 1)
    if host.startswith(".") or ".." in host or len(host) > 253 or not (1 <= int(port) <= 65535):
        raise BenchError("Invalid pool host or port.")
    return value


def validate_address(value):
    value = value.strip()
    if len(value) not in (95, 106) or value[0] not in ("4", "8") or not BASE58.fullmatch(value):
        raise BenchError("Enter a public Monero receiving address (95 or 106 Base58 characters). Never enter a seed or private key.")
    return value


def extract_verified_archive(blob: bytes) -> bytes:
    if hashlib.sha256(blob).hexdigest() != ASSET_SHA256:
        raise BenchError("Official XMRig archive SHA-256 mismatch; refusing to install.")
    with tarfile.open(fileobj=io.BytesIO(blob), mode="r:gz") as archive:
        files = [m for m in archive.getmembers()
                 if m.isfile() and not m.issym() and m.name.rsplit("/", 1)[-1] == "xmrig"
                 and 0 < m.size < MAX_BINARY]
        if len(files) != 1:
            raise BenchError("Unexpected XMRig archive structure.")
        fh = archive.extractfile(files[0])
        if fh is None:
            raise BenchError("XMRig executable missing from official archive.")
        result = fh.read(MAX_BINARY + 1)
        if len(result) > MAX_BINARY:
            raise BenchError("XMRig binary exceeds size limit.")
        return result


def local_binary(cache: Path, binary_override: str | None = None) -> Path:
    if binary_override:
        p = Path(binary_override).expanduser().resolve()
        if not p.is_file() or not os.access(p, os.X_OK):
            raise BenchError("The supplied --xmrig path is not an executable file.")
        return p
    if platform.system() != "Linux" or platform.machine().lower() not in MACHINE:
        raise BenchError("This quick installer currently supports Linux x86-64 only. No OS modifications made.")
    target = cache / "xmrig"
    receipt = cache / "xmrig_sha256.txt"
    if target.is_file() and receipt.is_file():
        if hashlib.sha256(target.read_bytes()).hexdigest() != receipt.read_text().strip():
            raise BenchError("Cached XMRig checksum changed. Remove the local cache and reinstall.")
        return target
    cache.mkdir(mode=0o700, parents=True, exist_ok=True)
    print(f"Downloading official XMRig {VERSION} ({ASSET}) ...", flush=True)
    req = urllib.request.Request(URL, headers={"User-Agent": "ZTM-Linux-Online-CPU/0.1"})
    with urllib.request.urlopen(req, timeout=45) as response:
        finalhost = urlparse(response.geturl()).hostname or ""
        if finalhost not in ("github.com", "release-assets.githubusercontent.com", "objects.githubusercontent.com"):
            raise BenchError("Official release download redirected to an unrecognized host.")
        blob = response.read(MAX_ARCHIVE + 1)
        if len(blob) > MAX_ARCHIVE:
            raise BenchError("XMRig download unexpectedly large.")
    exe = extract_verified_archive(blob)
    with tempfile.NamedTemporaryFile(dir=cache, prefix=".xmrig-", delete=False) as fh:
        temporary = Path(fh.name)
        fh.write(exe)
    try:
        temporary.chmod(0o700)
        os.replace(temporary, target)
        receipt.write_text(hashlib.sha256(exe).hexdigest() + "\n", encoding="ascii")
        receipt.chmod(0o600)
    finally:
        temporary.unlink(missing_ok=True)
    return target


def speed_hs(line):
    match = SPEED.search(line)
    if match is None or match.group(1).lower() == "n/a":
        return None
    value = float(match.group(1))
    units = (match.group(2) or "").lower()
    multiplier = {"": 1, "k": 1_000, "m": 1_000_000}[units]
    return value * multiplier if value > 0 else None


def prompt_if_missing(value, prompt):
    if value:
        return value
    if not sys.stdin.isatty():
        raise BenchError("Missing input. Run interactively or pass --pool and --wallet.")
    return input(prompt).strip()


def current_cpu_info():
    model = "Unknown"
    try:
        for line in Path("/proc/cpuinfo").read_text(encoding="utf-8", errors="replace").splitlines():
            if line.startswith("model name"):
                model = line.split(":", 1)[1].strip()
                break
    except OSError:
        pass
    return model


def run_benchmark(executable: Path, pool: str, wallet: str, tls: bool, duration_s: int,
                  threads: int | None, output_dir: Path, confirm: bool) -> tuple[dict, int]:
    if not confirm:
        if not sys.stdin.isatty():
            raise BenchError("Interactive authorization is required (or use --yes to explicitly consent).")
        print("\nYou are authorizing REAL online CPU mining for this short engineering test.")
        print(f"Pool: {pool} | TLS: {'enabled' if tls else 'disabled'} | Duration: {duration_s} seconds")
        print("All normal pool shares are attributed to the PUBLIC wallet address you entered.")
        print("XMRig also has its own configurable developer donation mechanism.")
        print("Mining consumes electricity, heats the CPU, and can be stopped with Ctrl+C.")
        if input("Type RUN to start this test: ").strip() != "RUN":
            raise BenchError("Authorization declined; no mining started.")
    output_dir.mkdir(parents=True, exist_ok=True)
    if output_dir.is_symlink():
        raise BenchError("Refusing to save results through a symlink directory.")
    collected = []
    state = {"accepted": 0, "rejected": 0, "connected": False, "lines": 0}
    lock = threading.Lock()
    start_wall = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    started = time.monotonic()
    interrupted = threading.Event()
    reached_deadline = False
    runid = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%d_%H%M%S")
    logfile = output_dir / f"run_{runid}.log"
    logfile.touch(mode=0o600, exist_ok=False)
    logfile.chmod(0o600)
    proc = None
    try:
        with tempfile.TemporaryDirectory(prefix="i2ps-rx-", dir=None) as tempdir:
            cfg_path = Path(tempdir) / "xmrig.json"
            cfg = {
                "autosave": False,
                "coin": "monero", "algo": "rx/0",
                "pools": [{"url": pool, "user": wallet, "pass": "x", "tls": tls, "keepalive": True}],
                "cpu": {"enabled": True, "huge-pages": True},
                "opencl": {"enabled": False}, "cuda": {"enabled": False},
                "print-time": 10, "colors": False,
                "http": {"enabled": False},
            }
            cfg_path.write_text(json.dumps(cfg), encoding="utf-8")
            cfg_path.chmod(0o600)
            command = [str(executable), "--config", str(cfg_path), "--no-color"]
            if threads is not None:
                command += ["--threads", str(threads)]
            print("\nStarting verified XMRig: actual CPU hashrate measurements will appear below.", flush=True)
            proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                    encoding="utf-8", text=True, errors="replace", bufsize=1,
                                    start_new_session=True)

            def collect():
                assert proc is not None and proc.stdout is not None
                with logfile.open("a", encoding="utf-8") as log:
                    for original in proc.stdout:
                        # Wallet is public, but do not retain it in logs or reports.
                        line = original.replace(wallet, "[PUBLIC_WALLET]")
                        log.write(line)
                        clean = re.sub(r"\x1b\[[0-9;]*m", "", line).strip()
                        value = speed_hs(clean)
                        match = SHARE.search(clean)
                        reject = REJECTED.search(clean)
                        with lock:
                            state["lines"] += 1
                            if value is not None:
                                collected.append(value)
                            if match:
                                state["accepted"] = max(state["accepted"], int(match.group(1)))
                                state["rejected"] = max(state["rejected"], int(match.group(2)))
                            if reject:
                                state["rejected"] = max(state["rejected"], int(reject.group(1)))
                            if "new job from" in clean.lower() or "use pool" in clean.lower():
                                state["connected"] = True
                        # Stream the real miner console to the ZTM GUI (never synthetic data).
                        print("[XMRig] " + clean, flush=True)
                        if value is not None:
                            print(f"  Measured XMRig speed: {value:,.1f} H/s", flush=True)
                        elif match or reject:
                            print(f"  Pool shares — accepted: {state['accepted']} | rejected: {state['rejected']}", flush=True)
                        elif any(term in clean.lower() for term in ("connect error", "connection refused", "invalid address", "invalid login", "unauthorized", "no active pools")):
                            print("  XMRig connection/authorization error; check the saved log.", flush=True)
            reader = threading.Thread(target=collect, daemon=True)
            reader.start()
            try:
                while True:
                    if proc.poll() is not None:
                        break
                    if time.monotonic() - started >= duration_s:
                        reached_deadline = True
                        break
                    time.sleep(0.2)
            except KeyboardInterrupt:
                interrupted.set()
                print("\nStopping XMRig by user request...", flush=True)
            finally:
                if proc.poll() is None:
                    proc.terminate()
                    try:
                        proc.wait(timeout=7)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        proc.wait(timeout=5)
                reader.join(timeout=5)
                if proc.stdout:
                    proc.stdout.close()
    except (OSError, subprocess.SubprocessError) as e:
        raise BenchError(f"Could not launch/read XMRig: {e}") from e

    elapsed = round(time.monotonic() - started, 1)
    with lock:
        values = collected[:]
        snapshots = state.copy()
    ran_full_time = reached_deadline and not interrupted.is_set() and len(values) > 0
    online_verified = snapshots["accepted"] > 0
    status = ("MEASURED_POOL_VERIFIED" if ran_full_time and online_verified else
              "PARTIAL_NO_ACCEPTED_SHARES" if ran_full_time else
              "STOPPED_OR_INCOMPLETE")
    report = {
        "project": "I2PS Dual-ISA RandomX Lab — online CPU ENGINEERING smoke test",
        "classification": "engineering_smoke_test_NOT_24h_v04_qualification",
        "recorded_at_utc": start_wall,
        "host_os": platform.platform(), "architecture": platform.machine(),
        "cpu_model": current_cpu_info(), "logical_cpus": os.cpu_count(),
        "xmrig_version_target": VERSION, "xmrig_executable": str(executable),
        "pool": pool, "tls": tls, "threads_requested": threads if threads else "automatic",
        "requested_seconds": duration_s, "elapsed_seconds": elapsed,
        "hashrate_samples": len(values),
        "median_hs": round(statistics.median(values), 2) if values else None,
        "mean_hs": round(statistics.fmean(values), 2) if values else None,
        "min_hs": round(min(values), 2) if values else None,
        "max_hs": round(max(values), 2) if values else None,
        "accepted_shares": snapshots["accepted"], "rejected_shares": snapshots["rejected"],
        "status": status, "actual_24_hour_benchmark": False,
        "source": "XMRig console readings; not independently calibrated",
    }
    target = output_dir / f"run_{runid}.json"
    target.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    target.chmod(0o600)
    print("\n" + "=" * 63)
    print(" I2PS RANDOMX — ACTUAL ONLINE CPU TEST RESULT")
    print("=" * 63)
    print(f" CPU:                 {report['cpu_model']}")
    print(f" Threads:             {report['threads_requested']}")
    print(f" Elapsed:             {elapsed:.1f} seconds / {duration_s} requested")
    print(f" Median hashrate:     {report['median_hs']} H/s")
    print(f" Average hashrate:    {report['mean_hs']} H/s")
    print(f" Accepted / rejected: {report['accepted_shares']} / {report['rejected_shares']}")
    print(f" Verification:        {status}")
    print(f" JSON report:         {target}")
    print(f" Diagnostic log:      {logfile}")
    print(" This is a short engineering test, NOT a 24-hour v0.4 certification.")
    print("=" * 63)
    if not values:
        return report, 3
    return report, 0 if ran_full_time and online_verified else 2


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--prepare", action="store_true", help="Only download and verify official XMRig; no mining")
    parser.add_argument("--session-stdin", action="store_true", help="Read pool, public wallet, duration and thread setting as JSON from stdin")
    parser.add_argument("--pool", help="Pool host:port supporting Monero/RandomX; prompted if omitted")
    parser.add_argument("--wallet", help="Public Monero receiving address; prompted if omitted; never a private key")
    parser.add_argument("--minutes", type=int, default=10, help="Run duration in whole minutes (default: 10)")
    parser.add_argument("--seconds", type=int, help=argparse.SUPPRESS)  # internal automated test option
    parser.add_argument("--threads", type=int, help="Mining CPU threads; default: XMRig chooses")
    parser.add_argument("--no-tls", action="store_true", help="For pools without TLS; default requires TLS")
    parser.add_argument("--xmrig", help="Use an existing XMRig executable instead of downloading it")
    parser.add_argument("--yes", action="store_true", help="Explicitly authorize CPU work without interactive RUN prompt")
    parser.add_argument("--plan", action="store_true", help="Show what this test would do; do not download or mine")
    parser.add_argument("--output", default=str(Path.home() / "i2ps-randomx-results"), help="Output directory for report/log")
    a = parser.parse_args(argv)
    if a.session_stdin:
        payload = json.loads(sys.stdin.readline())
        a.pool = payload.get("pool")
        a.wallet = payload.get("wallet")
        a.minutes = int(payload.get("minutes", 10))
        a.threads = int(payload["threads"]) if payload.get("threads") else None
        a.no_tls = not bool(payload.get("tls", True))
        a.yes = True  # GUI explicitly confirms BEFORE invoking --session-stdin
    if os.geteuid() == 0 and not a.plan:
        raise BenchError("Run as your normal Linux user, not as root or with sudo.")
    if not (1 <= a.minutes <= 1440) or (a.seconds is not None and not 1 <= a.seconds <= 86400):
        raise BenchError("Duration must be between 1 and 1440 minutes.")
    if a.threads is not None and not (1 <= a.threads <= (os.cpu_count() or 1)):
        raise BenchError("--threads must be between 1 and the detected logical CPU count.")
    if a.plan:
        print("I2PS ONLINE ENGINEERING SMOKE TEST — PLAN")
        print(f"- Platform: {platform.system()} {platform.machine()} | CPUs: {os.cpu_count()}")
        print(f"- XMRig: {'existing provided executable' if a.xmrig else VERSION + ' official upstream SHA-256 pinned Linux x64'}")
        print(f"- Duration: {a.seconds or a.minutes * 60} s | Threads: {a.threads or 'automatic'}")
        print(f"- TLS: {not a.no_tls} | Results: {a.output}")
        print("- Pool and PUBLIC Monero address are required; explicit consent before any mining")
        print("- No install/mining performed; no OS files or settings modified")
        return 0
    if a.prepare:
        local_binary(Path.home() / ".local" / "share" / "i2ps-randomx-test" / "xmrig-6.26.0", a.xmrig)
        print("ZTM PREPARATION COMPLETE: verified XMRig ready; no mining started", flush=True)
        return 0
    pool = validate_pool(prompt_if_missing(a.pool, "Pool server (host:port): "))
    wallet = validate_address(prompt_if_missing(a.wallet, "PUBLIC Monero receiving address (not private key): "))
    print(f"I2PS ENGINEERING ONLINE CPU TEST • CPU: {current_cpu_info()}")
    print("Only supported for Linux x86-64 in this version; existing OS is preserved.")
    executable = local_binary(Path.home() / ".local" / "share" / "i2ps-randomx-test" / "xmrig-6.26.0", a.xmrig)
    print(f"XMRig ready: {executable}")
    _, code = run_benchmark(executable, pool, wallet, not a.no_tls,
                            a.seconds or a.minutes * 60, a.threads,
                            Path(a.output).expanduser(), a.yes)
    return code


if __name__ == "__main__":
    try:
        sys.exit(main())
    except (BenchError, OSError, ValueError, KeyboardInterrupt) as exc:
        print(f"I2PS benchmark not started/completed: {exc}", file=sys.stderr)
        sys.exit(1)
